import { NextResponse } from "next/server";
import { addUser, current, listUsers, removeUser } from "../../../lib/auth";
export const dynamic = "force-dynamic";
export async function GET(request) { const user = current(request); if (!user || user.role !== "admin") return NextResponse.json({ error: "Non autorizzato" }, { status: 403 }); return NextResponse.json({ users: listUsers() }); }
export async function POST(request) { const user = current(request); if (!user || user.role !== "admin") return NextResponse.json({ error: "Non autorizzato" }, { status: 403 }); try { const body = await request.json(); return NextResponse.json({ user: addUser(body.username, body.password, body.role) }, { status: 201 }); } catch (error) { return NextResponse.json({ error: error.message === "USERNAME_EXISTS" ? "Username già esistente" : "Dati non validi" }, { status: 400 }); } }
export async function DELETE(request) { const user = current(request); if (!user || user.role !== "admin") return NextResponse.json({ error: "Non autorizzato" }, { status: 403 }); return NextResponse.json({ ok: removeUser(new URL(request.url).searchParams.get("id")) }); }
