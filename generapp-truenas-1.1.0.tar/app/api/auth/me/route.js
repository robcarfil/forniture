import { NextResponse } from "next/server";
import { current } from "../../../../lib/auth";
export const dynamic = "force-dynamic";
export async function GET(request) { return NextResponse.json({ user: current(request) }); }
