/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "standalone",
  experimental: { serverComponentsExternalPackages: [] },
  trailingSlash: true,
  images: {
    unoptimized: true
  }
};

export default nextConfig;
