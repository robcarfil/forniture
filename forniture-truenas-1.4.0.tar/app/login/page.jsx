"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function submit(event) {
    event.preventDefault();
    setMessage("");
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok) return setMessage(data.error || 'Credenziali non valide');
      // notify app about auth change
      try { window.dispatchEvent(new CustomEvent('auth:changed', { detail: { user: data.user } })); } catch (e) {}
      router.replace('/');
    } catch (err) {
      setMessage(String(err.message || 'Errore login'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="supplies-page">
      <div className="supplies-layout">
        <div className="supplies-content">
          <section className="panel summary-header-panel">
            <p className="eyebrow">Accesso</p>
            <h1>Login</h1>
            <p>Accedi per gestire le forniture.</p>
          </section>

          <section className="panel">
            {message && <p className="inline-message">{message}</p>}
            <form className="home-form" onSubmit={submit}>
              <label>
                Username
                <input value={username} onChange={(e) => setUsername(e.target.value)} required />
              </label>
              <label>
                Password
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </label>
              <div className="home-form-actions">
                <button type="submit" disabled={loading}>Accedi</button>
              </div>
            </form>
          </section>
        </div>
      </div>
    </main>
  );
}
