"use client";

import { useEffect, useState } from "react";
import SuppliesSidebar from "../SuppliesSidebar";

const utilityTypes = ["GAS", "ACQUA", "LUCE", "RIFIUTI"];
const emptyForm = { id: "", name: "", utilityType: "GAS", contact: "", logo: "", active: true };
const emptyCreateForm = { name: "", utilityType: "GAS", contact: "", logo: "" };

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function loadImage(dataUrl) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = reject;
    image.src = dataUrl;
  });
}

async function resizeLogoDataUrl(file, maxSize) {
  const source = await fileToDataUrl(file);
  if (file.type === "image/svg+xml") return source;

  const image = await loadImage(source);
  const ratio = Math.min(1, maxSize / Math.max(image.width, image.height));
  const width = Math.max(1, Math.round(image.width * ratio));
  const height = Math.max(1, Math.round(image.height * ratio));

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;

  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas non disponibile per ridimensionare il logo");
  context.drawImage(image, 0, 0, width, height);

  const outputType = file.type === "image/webp" ? "image/webp" : "image/png";
  return canvas.toDataURL(outputType, 0.92);
}

async function readJson(response) {
  const text = await response.text();
  const payload = text ? JSON.parse(text) : {};
  if (!response.ok) throw new Error(payload.error || `Errore API (${response.status})`);
  return payload;
}

function utilityFlag(type) {
  if (type === "ACQUA") return { icon: "💧", label: "Acqua", tone: "water" };
  if (type === "GAS") return { icon: "🔥", label: "Gas", tone: "gas" };
  if (type === "LUCE") return { icon: "💡", label: "Luce", tone: "light" };
  if (type === "RIFIUTI") return { icon: "🗑️", label: "Rifiuti", tone: "waste" };
  return { icon: "•", label: type || "Altro", tone: "default" };
}

export default function FornitoriPage() {
  const [loading, setLoading] = useState(true);
  const [providers, setProviders] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [createForm, setCreateForm] = useState(emptyCreateForm);
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [message, setMessage] = useState("");
  const [createLogoSize, setCreateLogoSize] = useState(320);
  const [editLogoSize, setEditLogoSize] = useState(320);

  async function chooseLogo(file, setter, size) {
    if (!file) return;
    if (file.size > 1_500_000) return setMessage("Il logo deve essere più piccolo di 1,5 MB");
    try {
      const resized = await resizeLogoDataUrl(file, Number(size) || 320);
      setter((prev) => ({ ...prev, logo: resized }));
      setMessage(file.type === "image/svg+xml" ? "Logo SVG caricato senza ridimensionamento" : "Logo ridimensionato con successo");
    } catch {
      setMessage("Impossibile ridimensionare il logo selezionato");
    }
  }

  async function loadProviders() {
    setLoading(true);
    try {
      const data = await readJson(await fetch("/api/forniture", { credentials: 'include' }));
      setProviders(data.providers || []);
      setMessage("");
    } catch (error) {
      setMessage(error.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadProviders();
  }, []);

  function resetForm() {
    setForm(emptyForm);
    setEditing(false);
  }

  function startEdit(provider) {
    setEditing(true);
    setForm({
      id: provider.id,
      name: provider.name || "",
      utilityType: provider.utilityType || "GAS",
      contact: provider.contact || "",
      logo: provider.logo || "",
      active: Boolean(provider.active)
    });
  }

  async function createProvider(event) {
    event.preventDefault();
    try {
      await readJson(
        await fetch("/api/forniture", {
          method: "POST",
          credentials: 'include',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ entity: "provider", ...createForm })
        })
      );
      setMessage("Fornitore creato");
      setCreateForm(emptyCreateForm);
      setCreateModalOpen(false);
      await loadProviders();
    } catch (error) {
      setMessage(error.message);
    }
  }

  async function saveProvider(event) {
    event.preventDefault();
    try {
      await readJson(
        await fetch("/api/forniture", {
          method: "PUT",
          credentials: 'include',
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ entity: "provider", ...form })
        })
      );
      setMessage("Fornitore aggiornato");
      resetForm();
      await loadProviders();
    } catch (error) {
      setMessage(error.message);
    }
  }

  async function deleteProvider(id) {
    if (!window.confirm("Eliminare questo fornitore?")) return;
    try {
      await readJson(await fetch(`/api/forniture?entity=provider&id=${id}`, { method: "DELETE", credentials: 'include' }));
      setMessage("Fornitore eliminato");
      if (form.id === id) resetForm();
      await loadProviders();
    } catch (error) {
      setMessage(error.message);
    }
  }

  return (
    <main className="supplies-page">
      <div className="supplies-layout">
        <SuppliesSidebar />

        <div className="supplies-content">
          <section className="panel summary-header-panel">
            <p className="eyebrow">Gestione Fornitori</p>
            <h1>Fornitori</h1>
            <p>CRUD completo dei fornitori per GAS, ACQUA, LUCE e RIFIUTI.</p>
            <button className="ghost" onClick={() => setCreateModalOpen(true)}>Nuovo fornitore</button>
          </section>

          {message && <p className="inline-message">{message}</p>}

          {editing && (
            <section className="panel home-form-panel">
              <div className="crud-title"><h2>Modifica fornitore</h2></div>
              <form className="home-form" onSubmit={saveProvider}>
                <label>
                  Nome fornitore
                  <input
                    value={form.name}
                    onChange={(event) => setForm((prev) => ({ ...prev, name: event.target.value }))}
                    required
                  />
                </label>
                <label>
                  Tipo fornitura
                  <select
                    value={form.utilityType}
                    onChange={(event) => setForm((prev) => ({ ...prev, utilityType: event.target.value }))}
                  >
                    {utilityTypes.map((item) => <option key={item} value={item}>{item}</option>)}
                  </select>
                </label>
                <label>
                  Contatto
                  <input
                    value={form.contact}
                    onChange={(event) => setForm((prev) => ({ ...prev, contact: event.target.value }))}
                  />
                </label>
                <label>
                  Logo
                  <div className="logo-size-row">
                    <span>Dimensione max lato (px)</span>
                    <select value={editLogoSize} onChange={(event) => setEditLogoSize(Number(event.target.value))}>
                      <option value={96}>96</option>
                      <option value={128}>128</option>
                      <option value={192}>192</option>
                      <option value={256}>256</option>
                      <option value={320}>320</option>
                      <option value={512}>512</option>
                    </select>
                  </div>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/svg+xml"
                    onChange={(event) => chooseLogo(event.target.files?.[0], setForm, editLogoSize)}
                  />
                  {form.logo && <img className="provider-form-logo" src={form.logo} alt="Logo fornitore" />}
                </label>
                <label className="checkbox-inline">
                  <input
                    type="checkbox"
                    checked={form.active}
                    onChange={(event) => setForm((prev) => ({ ...prev, active: event.target.checked }))}
                  />
                  Fornitore attivo
                </label>
                <div className="home-form-actions">
                  <button type="submit">Salva modifiche</button>
                  <button type="button" className="ghost" onClick={resetForm}>Annulla</button>
                </div>
              </form>
            </section>
          )}

          <section className="panel">
            <h2>Elenco fornitori</h2>
            {loading && <p className="muted">Caricamento...</p>}
            {!loading && !providers.length && <p className="muted">Nessun fornitore configurato.</p>}
            {!loading && providers.map((provider) => (
              <article className="line-item home-line-item" key={provider.id}>
                <div className="provider-item-main">
                  {provider.logo ? <img className="provider-logo" src={provider.logo} alt="" /> : <span className="provider-logo-fallback">{(provider.name || "F")[0].toUpperCase()}</span>}
                  <div>
                  <strong>{provider.name}</strong>
                  <small className={`utility-badge ${utilityFlag(provider.utilityType).tone}`}>
                    <span className="utility-icon" aria-hidden="true">{utilityFlag(provider.utilityType).icon}</span>
                    {utilityFlag(provider.utilityType).label}
                  </small>
                  <small>{provider.contact || "Nessun contatto"}</small>
                  </div>
                </div>
                <div className="home-row-actions">
                  <button className="ghost" onClick={() => startEdit(provider)}>Modifica</button>
                  <button className="danger" onClick={() => deleteProvider(provider.id)}>Elimina</button>
                </div>
              </article>
            ))}
          </section>

          {createModalOpen && (
            <div className="modal-backdrop" onClick={() => setCreateModalOpen(false)}>
              <section className="modal-card" onClick={(event) => event.stopPropagation()}>
                <h2>Nuovo fornitore</h2>
                <form className="home-form" onSubmit={createProvider}>
                  <label>
                    Nome fornitore
                    <input
                      value={createForm.name}
                      onChange={(event) => setCreateForm((prev) => ({ ...prev, name: event.target.value }))}
                      required
                    />
                  </label>
                  <label>
                    Tipo fornitura
                    <select
                      value={createForm.utilityType}
                      onChange={(event) => setCreateForm((prev) => ({ ...prev, utilityType: event.target.value }))}
                    >
                      {utilityTypes.map((item) => <option key={item} value={item}>{item}</option>)}
                    </select>
                  </label>
                  <label>
                    Contatto
                    <input
                      value={createForm.contact}
                      onChange={(event) => setCreateForm((prev) => ({ ...prev, contact: event.target.value }))}
                    />
                  </label>
                  <label>
                    Logo
                    <div className="logo-size-row">
                      <span>Dimensione max lato (px)</span>
                      <select value={createLogoSize} onChange={(event) => setCreateLogoSize(Number(event.target.value))}>
                        <option value={96}>96</option>
                        <option value={128}>128</option>
                        <option value={192}>192</option>
                        <option value={256}>256</option>
                        <option value={320}>320</option>
                        <option value={512}>512</option>
                      </select>
                    </div>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp,image/svg+xml"
                      onChange={(event) => chooseLogo(event.target.files?.[0], setCreateForm, createLogoSize)}
                    />
                    {createForm.logo && <img className="provider-form-logo" src={createForm.logo} alt="Logo fornitore" />}
                  </label>
                  <div className="home-form-actions">
                    <button type="submit">Crea fornitore</button>
                    <button type="button" className="ghost" onClick={() => setCreateModalOpen(false)}>Chiudi</button>
                  </div>
                </form>
              </section>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
