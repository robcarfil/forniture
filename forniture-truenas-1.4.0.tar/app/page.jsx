import FornitureSummaryPage from "./forniture/page";

export default function HomePage() {
  return <FornitureSummaryPage />;
}
