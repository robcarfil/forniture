"use client";
import { useEffect, useMemo, useState } from "react";

const money = (value, currency) => Number(value || 0).toLocaleString("it-IT", { style: "currency", currency: currency || "EUR" });

function Ranking({ title, rows, currency }) {
  const max = Math.max(1, ...rows.map(row => row.total));
  return <section className="report-panel"><div className="report-panel-heading"><h2>{title}</h2><span>{rows.length} voci</span></div>{rows.length ? <div className="report-ranking">{rows.map(row => <div className="report-ranking-row" key={row.name}><div className="report-ranking-label"><strong>{row.name}</strong><span>{money(row.total, currency)}</span></div><div className="report-bar-track"><i style={{ width: `${Math.max(3, row.total / max * 100)}%` }} /></div></div>)}</div> : <p className="muted">Nessun dato disponibile.</p>}</section>;
}

export default function ReportsPage() {
  const [accounts, setAccounts] = useState([]), [accountId, setAccountId] = useState(""), [transactions, setTransactions] = useState([]), [loading, setLoading] = useState(true);
  useEffect(() => { fetch("/api/banking?resource=accounts").then(response => response.json()).then(result => { const values = result.accounts || []; setAccounts(values); if (values[0]) setAccountId(values[0].id); }); }, []);
  useEffect(() => { if (!accountId) return; setLoading(true); fetch(`/api/banking/transactions/details?accountId=${accountId}`).then(response => response.json()).then(result => { setTransactions(result.transactions || []); setLoading(false); }); }, [accountId]);
  const account = accounts.find(item => item.id === accountId); const expenses = transactions.filter(item => Number(item.amount) < 0);
  const group = key => Object.values(expenses.reduce((result, item) => { const name = item[key] || "Senza categoria"; result[name] ||= { name, total: 0 }; result[name].total += Math.abs(Number(item.amount)); return result; }, {})).sort((a, b) => b.total - a.total);
  const categories = useMemo(() => group("categoryName"), [transactions]); const payees = useMemo(() => group("payeeName"), [transactions]);
  const totals = expenses.reduce((sum, item) => sum + Math.abs(Number(item.amount)), 0); const income = transactions.filter(item => Number(item.amount) >= 0).reduce((sum, item) => sum + Number(item.amount), 0);
  return <main className="settings-page banking-page reports-page"><header className="settings-header"><p className="eyebrow">Analisi finanziaria</p><h1>Report</h1><p>Analizza le spese del conto per categoria, sottocategoria e destinatario.</p><label className="report-account-select">Conto<select value={accountId} onChange={event => setAccountId(event.target.value)}>{accounts.map(item => <option value={item.id} key={item.id}>{item.name}</option>)}</select></label></header>{account && <><section className="report-kpis"><div><small>Entrate</small><strong className="income">{money(income, account.currency)}</strong></div><div><small>Spese</small><strong className="expense">{money(totals, account.currency)}</strong></div><div><small>Transazioni</small><strong>{transactions.length}</strong></div></section>{loading ? <p className="muted">Caricamento report...</p> : <div className="reports-grid"><Ranking title="Spese per categoria e sottocategoria" rows={categories} currency={account.currency} /><Ranking title="Spese per destinatario" rows={payees} currency={account.currency} /></div>}</>}{!accounts.length && <section className="settings-card"><p className="muted">Nessun conto disponibile.</p></section>}</main>;
}
